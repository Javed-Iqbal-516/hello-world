<?php include('layouts/header.php'); ?>
<div class="container-fluid home-page">
    <h1 style="text-align:center;padding:150px 0px;"><i class="fa fa-globe"></i> <?php // echo get_option('site_name'); ?>Test</h1>
	<!-- <h1><?phpv // $test=$app->crud->a("users",false);
	// echo $test->first_name; ?></h1> -->
</div>

<?php include('layouts/footer.php'); ?>