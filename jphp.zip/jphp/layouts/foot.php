	<?php foot();js('index'); ?>
  </body>
</html>