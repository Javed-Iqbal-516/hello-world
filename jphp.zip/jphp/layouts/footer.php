<div class="container-fluid">
	
	<footer class="row">

	</footer>

</div>

<?php include("foot.php"); ?>