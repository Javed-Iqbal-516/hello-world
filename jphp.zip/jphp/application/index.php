<?php

	
	require_once('config/config.php');
	require_once('config/database.php');
	
	require_once('crud.php');
	$crud=new Crud;
	require_once('plugins.php');

	// loading helpers
	require_once('helpers/form_helpers.php');
	require_once('helpers/url_helpers.php');

?>