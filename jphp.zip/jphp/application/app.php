<?php

/*
|--------------------------------------------------------------------------
| App
|--------------------------------------------------------------------------
|
| Description:
|
*/


class App
{
	
	function __construct()
	{
		$this->load();
	}

	public function load()
	{
		require_once("load.php");
		foreach ($autoload['models'] as $key => $model) {
			$model_name=ucfirst($model);
			$this->$model=new $model_name;
		}
	}



}
$app=new App;
?>