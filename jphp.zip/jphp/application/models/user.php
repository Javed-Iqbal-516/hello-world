﻿<?php 

/*
|--------------------------------------------------------------------------
| User Class
|--------------------------------------------------------------------------
|
| Description : 
|
*/

class User extends Crud
{
	
	function __construct()
	{
		# code...
	}

	public function user_check($type='admin',$path='index.php',$button='btn-login')
	{
		if(isset($_POST[$button])) {

			$email 	  = p('email');
			$password = _hash('password');
			$result = q("select * from `users` where `email`='$email' and `password`='$password' and type='$type' and active ='0'");
			if(mysqli_num_rows($result)>0){
				
				$user=mysqli_fetch_assoc($result);
				
				if($type=='admin') {
					$_SESSION['admin']= $user;
				}
				else {
					$_SESSION['user']= $user;
				}
				
				redirect($path);
			}
			else {
				$_SESSION['error']='Invalid email or password';
			}
			
		}
	}
	function u($id){
		return a("users where id='$id'",false);
	}

	function ath($redirect=true) {
		//athorising user
		if(!isset($_SESSION['user'])) {
			if($redirect==true) {
				redirect('sign_in.php');
			} else {
				return false;
			}
		} else {
			return $_SESSION['user'];
		}
	}

	function forget($test=false) 
	{
		$root=c_p();
		if(set('forget')) {
			$email=p('email');
			$r=all("users where email='$email'");
			if(mysqli_num_rows($r)>0) {
				$rr=mysqli_fetch_assoc($r);
				$pass=$rr['password'];
				$r=rand();
				$link="Forget Password Confirmation Link \r\n ";
				$link.=$root."new_password.php?email=$email&hash=$pass&".$r;
				if($test==true){
					echo $link;
				}
				$subject = "Cofirmation Email";
				// $txt = "Hello world!";
				$headers = "From: stadnerz.se \r\n" .
				"CC: $email";
				mail($email,$subject,$link,$headers);
				
				sm("Confirmtion Link Sent to Your Email Address.");
			} else {
				sm("Email Not Exists",false);
			}
		}

		
	}
	
	function new_pass(){
		if(set('email') && set('hash')) {
			$email=g('email');
			$password=g('hash');
			$r=all("users where email='$email' and password ='$password'");
			if(mysqli_num_rows($r)>0) {

				if(set('new_pass')){
					if(p('password')==p('confirm')) {
						$password=_hash('password');
						q("update users set password='$password' where email='$email'");
						sm("Your Password is Changed.");
					} else {
						sm("Password Confirmation Not Matched.",false);
					}
				}
			
			}
			else {
				redirect('index.php');
			}
			
		} else {
			redirect('index.php');
		}
	}



	function update_password($type='user'){
		if (set('update_password')) {		
			if ($type=='admin') {
				$user_id=$_SESSION['admin']['id'];
			}else{
				$user_id=$_SESSION['user']['id'];
			}
			$user=u($user_id);
			$olds=$user['password'];
			$old=_hash('old');
			if($old==$olds) {
				if(p('password')==p('confirm_pass'))
				{
				$dp['password']=_hash('password');
				$res=update('users',$dp,$user_id,false);
				if($res)
				{
				 sm("Password is Updated successfull");
				}
				}
				else{sm(" Password Confirmation is wrong",false);}
			}
			else{
				sm(" Enter Correct Password",false);
			}
			// redirect("password.php");
		}

	}


}
	
?>