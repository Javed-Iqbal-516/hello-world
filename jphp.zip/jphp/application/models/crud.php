﻿<?php 

/*
|--------------------------------------------------------------------------
| Crud
|--------------------------------------------------------------------------
|
| Crud is db library with crud methods
| version : 5.0
|
*/

	class Crud
	{

		/**
		 * Vairable for storing database connection object
		 *
		 * @var Mysqli object
		 */

		public $con;
		
		function __construct() {	
			// Database Connection
			$this->con=mysqli_connect(HOST,USERNAME,PASSWORD,DBNAME);
            if(!$this->con) {
                die('database connection failed');
                exit();
            }
		}

		function __destruct() {
			// Closing database connection
			// mysqli_close($this->con);
		}


		// q executes the query
		public function q($sql) {
			$query=mysqli_query($this->con,$sql);
			if($query){
				return $query;
			} else {
				echo mysqli_error($this->con);
			}
		}

		// fetching data with query
		public function ac($sql,$multi=true) {
			$output=array();
			$res_table=$this->q($sql);			
			if($res_table) { 
				while($row_table=mysqli_fetch_object($res_table)) {
					if($multi==true){
						$output[]=$row_table;
					}else{
						$output=$row_table;
					}
				}
				return $output;
			}
		}

		// fetching all data with table
		public function a($table,$multi=true,$id='',$field='id') {

			$sql="select * from ";
			$sql.=$table;
			
			if (!empty($id)) {
				$sql.=" where $field='$id' ";
			}

			return $this->ac($sql,$multi);
		}

		// simple insert
		public function si($table,$data,$post=false)
		{
			global $con;
			if($post==true) {
				$d2=post($data);
			}
			else{
				$d2=$data;
			}
			
			$fields = "";
			$values = "";
			 // populate them
			foreach ($d2 as $f => $v) {
				$fields .= "`$f`,";
				$values .= ( is_numeric( $v ) && ( intval( $v ) == $v ) ) ?
				$v."," : "'$v',";
			}
			// remove our trailing ,
			$fields = substr($fields, 0, -1);
			// remove our trailing ,
			$values = substr($values, 0, -1);
			$sql = "INSERT INTO `$table` ({$fields}) VALUES({$values})";
			$this->q($sql);
			return mysqli_insert_id($this->con);
		}

		// insert with fields
		public function insert($table='',$fields,$extra=array()){
			$form_posts=form_posts($fields);
			$data=array_merge($form_posts,$extra);
			return $this->si($table,$form_posts);
		}

		// simple update
		public function su($table,$data,$id='',$field='id',$post=false )
		{

			if($post==true) {
				$d2=post($data);
			}
			else{
				$d2=$data;
			}


			$sql = "UPDATE " . $table . " SET ";
			foreach( $d2 as $field => $value )
			{
			$sql .= "`" . $field . "`='{$value}',";
			}
			 // remove our trailing ,
			$sql = substr($sql, 0, -1);
			$sql .= "WHERE $field=".$id;
			return $this->q($sql);
		}

		public function update($table='',$fields,$id='',$field='id',$extra=array()){
			$form_posts=form_posts($fields);
			$data=array_merge($form_posts,$extra);
			return $this->su($table,$form_posts,$id,$field);
		}

		public function del($table,$id,$field='id') {

			return $this->q("delete from {$table} where $field='$id'");

		}


		// cleardata
		public function clear($input) {
			$input=mysqli_real_escape_string($this->con,$input);
			$input=htmlspecialchars($input);
			//$input=htmlentities($input);
			$input = trim($input);
			//$input= stripslashes($input);
			return $input;
		}



	}
	
?>