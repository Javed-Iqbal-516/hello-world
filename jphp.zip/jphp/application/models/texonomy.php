<?php 

/*
|--------------------------------------------------------------------------
| Texonomy Class 
|--------------------------------------------------------------------------
|
| Description : 
|				eg  type=category
|
*/

class Texonomy extends Crud
{
	
	function __construct()
	{
		# code...
	}


}

?>