<?php 

/*
|--------------------------------------------------------------------------
| Options Class
|--------------------------------------------------------------------------
|
| Description : 
|
*/

class Options extends Crud
{
	
	function __construct()
	{
		# code...
	}

	function get($option,$show=false){
		$option=a("settings where site_option='$option'",false);

		if ($show) {
			echo $option['value'];
		} else {
			return $option['value'];
		}

	}


}

?>