﻿<?php

/*
|--------------------------------------------------------------------------
| Config
|--------------------------------------------------------------------------
*/
	ob_start();
	session_start();

	//true or false
	$development=true;

	if (!$development) {
		error_reporting(0);
	}

	define("path","http://localhost/newproject_5/");

?>
