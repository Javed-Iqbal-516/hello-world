﻿<?php

/*
|--------------------------------------------------------------------------
| Main Config
|--------------------------------------------------------------------------
*/
	
	// config
	require_once('config.php');
	//database config 
	require_once('database.php');
	//autoloads config 
	require_once('autoload.php');

?>
