﻿<?php

/*
|--------------------------------------------------------------------------
| Autoloads Config
|--------------------------------------------------------------------------
*/

	// helpers
	$autoload['helpers']=array("form/submit","form/dynamic","plugins","session","site","strings","test","url");
	// models
	$autoload['models']=array("crud","options","texonomy","user");

?>
