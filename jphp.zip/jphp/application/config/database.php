﻿<?php

/*
|--------------------------------------------------------------------------
| Database Config
|--------------------------------------------------------------------------
*/

	if ($development) {

		define("HOST","localhost");
		define("USERNAME","root");
		define("PASSWORD","");
		define("DBNAME","project_5");

	} else {		

		define("HOST","");
		define("USERNAME","");
		define("PASSWORD","");
		define("DBNAME","");

	}

?>
