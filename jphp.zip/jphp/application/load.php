﻿<?php

/*
|--------------------------------------------------------------------------
| Load app
|--------------------------------------------------------------------------
*/

	// loading config
	require_once('config/index.php');

	// loading helpers
	foreach ($autoload['helpers'] as $key => $helper) {
		require_once("helpers/".$helper.".php");
	}

	// loading models
	foreach ($autoload['models'] as $key => $model) {
		require_once("models/".$model.".php");
	}


?>
