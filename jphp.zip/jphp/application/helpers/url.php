﻿<?php 

/*
|--------------------------------------------------------------------------
| Url Helpers Functions
|--------------------------------------------------------------------------
|
| Description:
|
*/

	//return domain name
	function domain() {
		return $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'];
	}

	function redirect($new_location) {
		// header("Location:".$new_location);
		?>
			<script>window.location.href="<?php echo $new_location ?>"</script>
		<?php
		
	}

	function c_p(){
		$root = domain();
		$root .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);
		return $root;
	}


	function c_f() {
		//current file name
		$path=$_SERVER['SCRIPT_FILENAME'];
		$path=pathinfo($path, PATHINFO_FILENAME);
		return $path;
	}
	
	function a_c($file) {
		$path=c_f();
		if($path==$file){echo 'active';} 	
	}


?>