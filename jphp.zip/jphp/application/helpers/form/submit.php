﻿<?php 

/*
|--------------------------------------------------------------------------
| Submitted Form Helpers Functions
|--------------------------------------------------------------------------
|
| Description:
|
*/

	// if set post or get
	function set($val,$type='p') {
		if ($type=='p') {
			return (isset($_POST[$val])) ? true : false ;
		}else{
			return (isset($_GET[$val])) ? true : false ;
		}
	}

	// return cleared post value
	function p($field) {
		global $crud;
		if(set($field)) {
			return $crud->clear($_POST[$field]);
		} else {
			echo $field. 'Not Posted.';
		}
	}

	//retrun cleared get value
	function g($field) {
		global $crud;
		if(set($field,'g')) {
			return $crud->clear($_GET[$field]);
		} else {
			echo $field. 'Not Get.';
		}

	}

	// getting posts values
	function post($fields) {
		// input (text,number etc),textarea,select
		$d2=array();		
		foreach($fields as $field){
			$d2[$field]=p($field);
		}
		return $d2;
	}

	//checkbox 
	function check($field) {
		if(set($field)) {
			return implode(',',p($field));
		}
	}

	//radio
	function radio($field) {
		if(set($field)) {
			return p($field);
		}
	}

	function _hash($field,$test=false) {
		
		if ($test) {
			$password=$field;
		}else{
			$password=p($field);
		}
		$salt="loremipsemd34992034904e0iouien3j";
		$password.=$salt;
		return hash('sha256',$password);
	
	}

	//simple upload
	function su($field='') {
		$file=$_FILES[$field];
		$file_name=time().$file['name'];
		$tmp_name=$file['tmp_name'];
		if(move_uploaded_file($tmp_name,'uploads/'.$file_name)){
			return $file_name;			
		} else {
			sm('upload error',false);
		}

	} 

	// file upload
	function upload($field) {
		// file validation
		//if no error is found then upload the file
		if (empty($_SESSION['error'])) {
		
			$field_name=$field['field'];
			$image=$_FILES[$field_name];
			if($image['name']!='') {
				$image_name=time().$image['name'];
				$tmp_name=$image['tmp_name'];
	//
			$file_type = pathinfo('uploads/'.$image_name,PATHINFO_EXTENSION);
			//This size is for checking img is real or not
			$type=getimagesize($tmp_name);
			if(!$type && $field['image'])
			{
				sm('This is not image',false);
			}

			if($image['size']>$field['size'])//100000=100kB
			{
				sm('sorry file size is large',false);
			}

			$filetypes=$field['file_types'];
			$types=implode(",",$filetypes);
			$t_count=0;
			foreach ($filetypes as $key => $f_type) {
				if ($file_type==$f_type) {
					$t_count=1;
				}
			}
			if ($t_count==0) {
				sm(" Only ".$types." Are Upload.",false);
			}

	//		
				if(empty($_SESSION['error'])){
					// $this->simpe_upload();
				} else {
					return false;
				}	

			} else {
				return false;
			}
		}
	}


	function form_posts($fields=array()){
		$output=array();
		foreach ($fields as $key => $field) {
			// type
			$type=$field[0];
			$name=$field[1];
			$label=$field[2];
			if ($type=='text' || $type=='number' || $type=='select' || $type=='textarea') {
				$output[]=p($name);
			}elseif ($type=='checkbox') {
				$output[]=check($name);
			}elseif ($type=='radio') {
				$output[]=radio($name);
			}elseif ($type=='file') {
				$output[]=su($name);
			}elseif($type=='password'){
				$output[]=_hash($name);
			}
		}
	}



?>