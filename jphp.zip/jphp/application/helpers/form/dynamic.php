﻿<?php 

/*
|--------------------------------------------------------------------------
| Dynamic form Helpers Functions
|--------------------------------------------------------------------------
|
| Description:
|
*/

    function dynamic_field($field,$options,$row,$action){
        $field_type=$field['type'];
        $field_name=$field['field'];
        $field_label=$field['label'];

  		if ($field_type=='text' || $field_type=='email' || $field_type=='file') { ?>

            <input type="<?php echo $field_type; ?>" value="<?php if($action=='update'){echo $row->$field_name;}  ?>" name="<?php echo $field_name; ?>" class="form-control" placeholder="Enter <?php echo $field_label; ?>" >

		<?php } else if($field_type=='select') { ?>
             
    		<select name="<?php echo $field_name; ?>" id="" class="form-control">
                <?php 
                        $select_options=$options[$field_name];
                        foreach ($select_options as $key=> $option) {
                            echo "<option";echo " value='".$key."' ";
                            if($action=='update') {
                                if ($row->$field_name==$key) {
                                    echo "selected";
                                }
                            }
                            echo " >";echo $option;echo "</option>";
                        }
                        //if field type=text area

                         ?>
                  </select>
		<?php } elseif ($field_type=='textarea') {  ?>

    		<textarea name="<?php echo $field_name; ?>" id="" cols="30" rows="10" class="form-control"><?php if($action=='update'){echo $row->$field_name;}  ?></textarea>
              
    	<?php } ?>
           <?php

	}

?>