<?php

/*
|--------------------------------------------------------------------------
| Test Helpers Functions
|--------------------------------------------------------------------------
|
| Description:
|
*/

	function words($sentence, $count = 10) {

		preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
		return $matches[0];

	}	


?>