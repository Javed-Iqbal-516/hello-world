<?php 

/*
|--------------------------------------------------------------------------
| Session Helpers Functions
|--------------------------------------------------------------------------
|
| Description:
|
*/

	function msg()
	{
		if(isset($_SESSION['msg']))
		{
			$output="<div class='alert alert-success'><i class='fa fa-check-circle'></i> Success: ";
			$output.=$_SESSION['msg'];
			$output.="<button type='button' class='close' data-dismiss='alert'>&times;</button></div>";
			$_SESSION['msg']=null;
			echo $output;
		}

		if(isset($_SESSION['error']))
		{
			$output="<div class='alert alert-danger'>";
			foreach ($_SESSION['error'] as $key => $error) {
				# code...
				$output.="<i class='fa fa-exclamation-circle'></i> Warning: ";
				// if error is single or single string
				$output.=$error;        
				if ($key==0) {
					# code...
					$output.="<button type='button' class='close' data-dismiss='alert'>&times;</button>";
				}
				$output.="<br>";
			
			
			}

			$output.="</div>";
			// Clear errors after displayed
			$_SESSION['error']=null;
			echo $output;
		}
		
	}

	function sm($m,$msg=true){
		
		if($msg==true) {
			$_SESSION['msg']=$m;
		} else {
			$_SESSION['error'][]=$m;
		}
		
	}



?>