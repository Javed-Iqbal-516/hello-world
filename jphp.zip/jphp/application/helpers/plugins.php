<?php 
	/*
		plugins function
	*/

	$plugs['bootstrap']=array('css'=>true,'js'=>true);
	$plugs['font-awesome']=array('css'=>true,'js'=>false);
	$plugs['jquery-3.2.1']=array('css'=>false,'js'=>true);

	$_SESSION['plugs']=$plugs;
	function plug_css($plugins=array()){
		foreach ($plugins as $key => $plugin) {
			$bs=path;
			// print_r($plugs);
			if ($_SESSION['plugs'][$plugin]['css']) {
				$path=$bs."assets/plugins/".$plugin."/css/".$plugin.".min.css";
				echo '<link rel="stylesheet" href="'.$path.'"/>';
			}
		}
	}

	function plug_js($plugins=array()){
		global $plugs;
		foreach ($plugins as $key => $plugin) {
			if ($_SESSION['plugs'][$plugin]['js']) {
				$path=path."assets/plugins/".$plugin."/js/".$plugin.".min.js";
				echo '<script src="'.$path.'"></script>';
			}
		}
	}

	function js($file=''){
		// defer
		echo '<script src="assets/js/'.$file.'.js"></script>';
	}
	function css($file=''){
		echo '<link rel="stylesheet" href="assets/css/'.$file.'.css">';
	}

	function foot(){
		$plugins=$_SESSION['plugins'];
		plug_js($plugins);
	}

	function head($plugins=array()){
		$_SESSION['plugins']=$plugins;
		plug_css($plugins);
	}



?>