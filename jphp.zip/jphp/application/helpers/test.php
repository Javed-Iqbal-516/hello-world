<?php 

/*
|--------------------------------------------------------------------------
| Test Helpers Functions
|--------------------------------------------------------------------------
|
| Description:
|
*/

	function pr(){
		//profiler
		echo '<div style="border:1px solid red;padding:30px;margin:15px;position:absolute;background-color:#000;color:#fff;width:80%;">';
		echo '<pre>';
		echo '<h1>POST</h1>';
		print_r($_POST);
		echo '<h1>GET</h1>';
		print_r($_GET);
		echo '<h1>FILES</h1>';
		print_r($_FILES);
		echo '<h1>SESSION</h1>';
		print_r($_SESSION);
		echo '<h1>Query Error:</h1>';
		e();
		echo '</pre>';
		echo '</div>';
	}
	
	function test($var){
		echo '<div style="border:1px solid red;padding:30px;margin:15px;position:absolute;background-color:#000;color:#fff;width:80%;"><pre>';
		print_r ($var);

		echo '<p>Var dump</p>';
		var_dump($var);
		echo '</pre></div>';

	}

	function fun_definded_line($function_name){

		$reflFunc = new ReflectionFunction($function_name);
		print $reflFunc->getFileName() . ':' . $reflFunc->getStartLine();
	}


?>