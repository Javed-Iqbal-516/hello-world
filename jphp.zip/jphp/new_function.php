<?php

if user enter wrong password ,after five attemps his account is blocked for security reason
msg show to user:Your account has been bloked for security reason,please contact to your admin of site.
categories table like media

new functions start_project
    import sql to database and remove sql file
new function close_project
    export sql from database and remove database if needed,
