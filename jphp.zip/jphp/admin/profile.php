<?php
include("header.php");
include("aside.php");

/*
	=========================================================
	=========================================================
*/

$slug_name='Admin';
$slug_multiple='Admin';
$slug='profile';
$table='users';
$fields=array('first_name','email');
$_SESSION['record']=array(
							'table'=>$table,
							'slug_name'=>$slug_name,
							'slug'=>$slug,
							'fields'=>$fields,
							'photo'=>'',
						);

/*
	=========================================================
	=========================================================
*/

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
		Update Profile
		<ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>
<br />
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
		<div class="box">
			<div class="box-header with-border">
			<h1>Update Profile</h1>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
				<div class='row col-lg-12' style="margin-top:15px;">
					<?php
						msg();
					?>
				</div>

			</div>
			<div class="box-body">           

	
		   <div class="box box-primary">
           
            <!-- /.box-header -->
					<form action="process_profile.php" method="post" enctype="multipart/form-data">
<?php
				$row = a("$table where id = '$user_id'",false);
?>
                  <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div class="form-group">
                        <label class="form-label">Name</label>
                        <div class="controls">
                          <input type="text" class="form-control" value="<?php echo $row['first_name']; ?>" name="first_name" required >
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="form-label">Phone No</label>
                        <div class="controls">
                          <input type="text" class="form-control" name="phone_no" value="<?php echo $row['phone_no']; ?>" placeholder="Enter Phone No" required  />
                        </div>
                      </div>

                      
					  <div class="form-group">
                        <label class="form-label">Image</label>
                        <div class="controls">
                          <input type="file" class="form-control" name="image"   />
                        </div>
                      </div>
					  
					  <div class="form-group">
                <button type="submit" name="update_profile" class="btn btn-primary">Update</button>
							</form>
					  </div>
                     </div>
                  </div>
					</form>

            <!-- form start -->
</div>
			</div>
        <!-- /.box-body -->
		</div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


   <aside class="control-sidebar control-sidebar-dark">
    <div class="tab-content">
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
      <div class="tab-pane" id="control-sidebar-stats-tab"></div>
    </div>
  </aside>

<!-- ./wrapper -->

<?php include("footer.php");?>