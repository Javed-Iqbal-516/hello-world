<?php
include('config.php');

	$record=$_SESSION['record'];
	$table=$record['table'];
	$slug=$record['slug'];
	$slug_name=$record['slug_name'];
	$fields=$record['fields'];
	$photo=$record['photo'];

	if(isset($_POST["add_{$slug}"]) || isset($_POST["update_{$slug}"])) {
		if(isset($_POST["add_{$slug}"])) {		
			$res=insert($table,$fields);
			if($res) {
				$_SESSION['msg']="{$slug_name} is added successfull";
				redirect("{$slug}.php?action=view");
			}
		}
		
		if(isset($_POST["update_{$slug}"]))	{
			
			/* deleting old pic */
			$user_id=$_SESSION['admin']['id'];
			$dp['first_name']=p('first_name');
			$dp['phone_no']=p('phone_no');
			$photo=$_FILES['image'];
			if($photo['name']!='') {
				$img=time().$photo['name'];
				$tmp_name=$photo['tmp_name'];
				move_uploaded_file($tmp_name,'uploads/'.$img);
				$dp['image']=$img;
			}
			$res=update($table,$dp,$user_id,false);
			if($res)
			{
			 $old=$_SESSION['admin']['image'];
			 unlink('uploads/'.$old);
			 $_SESSION['admin']['image']=$img;
			 $_SESSION['msg']="{$slug_name} is Updated successfull";
			 redirect("profile.php");
			}
		}
	}
	elseif(isset($_GET['action']))
	{
		if($_GET['action']=='delete')
		{
			$id=$_GET['delete'];
			/* deleting old pic */
			if($photo!='')
			{
				$sqlres=all("$table where id='$id'");
				if(mysqli_num_rows($sqlres)>0)
				{
					$row=mysqli_fetch_assoc($sqlres);
					$img=$row[$photo];
					$del_path='uploads/'.$img;
					unlink($del_path);
				}
			}
			
			del($table,$id);
			$_SESSION['msg']="{$slug_name} is Deleted";
			redirect("{$slug}.php?action=view");				
		}
	}
	else
	{
		redirect('index.php');
	}
?>