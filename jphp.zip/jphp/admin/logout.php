<?php
session_start();
if(isset($_SESSION['admin'])) {
	unset($_SESSION['admin']);
}else {
	unset($_SESSION['user']);
}
header("location:../index.php");
?>