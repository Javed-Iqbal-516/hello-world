<?php
include('includes/config.php');

	$record=$_SESSION['record'];
	$table=$record['table'];
	$slug=$record['slug'];
	$slug_name=$record['slug_name'];
	$fields=$record['fields'];
	$extra_fields=$record['extra_fields'];
	$delete_permission=$record['delete_permission'];
	$post_fields=array();
	$file_fields=array();
	$checkbox_fields=array();

	$file_fields_names=array();
	foreach ($fields as $key => $field) {
		if ($field['type']=='file') {
			$file_fields[]=$field;
			$file_fields_names[]=$field['field'];
		} elseif($field['type']=='checkbox') {

			$checkbox_fields[]=$field['field'];

		}else{
			$post_fields[]=$field['field'];			
		}
	}


	// print_r($post_fields);
	if(isset($_POST["add_{$slug}"]) || isset($_POST["update_{$slug}"])) {
		$p_fields=post($post_fields);
		$c_fields=check($checkbox_fields);
		//test($post_fields);	
		if(isset($_POST["add_{$slug}"])) {
			$f_fields=files($file_fields);
			//any validation etc check is write here that call sm('string',false),if validaion false;
			$data=array_merge($p_fields,$f_fields);
			$data=array_merge($data,$extra_fields);
			$data=array_merge($data,$c_fields);
			//if no errrors or validation errors then data is inserted
			if (empty($_SESSION['error'])) {
				$res=insert($table,$data,false);
				if($res) {
					$_SESSION['msg']="{$slug_name} is added successfull";
					redirect("{$slug}.php?action=view");	
				}
			} else {
					redirect("{$slug}.php?action=add");					
			}
		}
		
		if(isset($_POST["update_{$slug}"]))	{
			
			$id=$slug.'_id';
			$id=$_POST[$id];
			/* deleting old pic */

			$f_fields=files($file_fields,true,$table,$id);
			$data=array_merge($p_fields,$f_fields);
			$data=array_merge($data,$c_fields);
			//if no errors or validation error
			if (empty($_SESSION['error'])) {			
				$res=update($table,$data,$id,false);
				if($res)
				{
					$_SESSION['msg']="{$slug_name} is Updated successfull";
				redirect("{$slug}.php?action=view");
				}
			} else {
					redirect("{$slug}.php?action=update&update=".$id);				
			}

		}
	}
	elseif(isset($_GET['action']))
	{
		if($_GET['action']=='delete' && $delete_permission)
		{
			$id=$_GET['delete'];
			/* deleting old pic */
			$f_fields=unlink_files($table,$id,$file_fields_names);

			del($table,$id);
			$_SESSION['msg']="{$slug_name} is Deleted";
			redirect("{$slug}.php?action=view");				
		}else{
			redirect('index.php');
		}
	}
	else
	{
		redirect('index.php');
	}
?>