<?php
include("header.php");
include("aside.php");

/*--------------------------------------------------------------------------------------------------
										CONFIG
---------------------------------------------------------------------------------------------------*/

$slug_name		=	'User';
$slug_multiple	=	'Users';
$table 			=	'users';
$slug=c_f();
//500000000 50mb
$fields= array();
$fields[] = array('field' => 'first_name','label' => 'First Name','type' => 'text');
$fields[] = array('field' => 'email','label' => 'Email','type' => 'email');
$fields[] = array('field' => 'image','label' => 'User Image','type' => 'file','file_types'=>array('jpg','jpeg','png'),'size'=>'200000000','image'=>true);
$fields[] = array('field' => 'sub_type','label' => 'Select Type','type' => 'select');
$fields[] = array('field' => 'checklist','label' => 'Checklist','type' => 'checkbox');
$extra_fields=array();
$extra_fields['type']='user';
//if field is select with indexs,or selecting from table
$options['sub_type']=array('user'=>'User','cleaner'=>'Cleaner');

$options['checklist']=array('legally'=>'Legally Residing in Sweden','f_tax'=>'Have an f-tax');
$permissions=array('add'=>true,'view'=>true,'update'=>true,'delete'=>true);

$action=set_record($table,$slug_name,$slug,$fields,$extra_fields,$permissions);

/*-------------------------------------------------------------------------------------------------*/
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <?php content_header(); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
		<div class="box">
  			<?php box_header(); ?>
			<div class="box-body">           
			<?php
					add_update();
					if($action=='view')
					{
						?>
		<div class="table-responsive">
          <table id="example2" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <?php view_table_headings(); ?>
		          <th>Action</th>
                </tr>
                </thead>
                <tbody>
				<?php
				  $result = a($table);
				  foreach($result as $row){
				?>
                <tr>
                  <td><?php echo $row['id']; ?></td>
                  <?php view_fields($row); ?>
                  <td>
                  	<?php update_delete_btns($row);?>
				  </td>
                </tr>
				  <?php }?>
                </tbody>
              </table>
       		</div>	
				<?php }	?>
			</div>
        <!-- /.box-body -->
		</div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php theme_aside(); ?>
<!-- ./wrapper -->
<?php include("footer.php");?>