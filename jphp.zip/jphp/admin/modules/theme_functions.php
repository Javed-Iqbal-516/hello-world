<?php

	function add_button(){
		global $action,$permissions,$slug,$slug_name;
		if($action=='view' && $permissions['add'])
		{
			echo '<a href="'.$slug.'.php?action=add" class="fa fa-plus-circle btn btn-primary"> Add '.$slug_name.'</a>';
		}

	}

	function view_slug(){
		global $action,$slug_name,$slug_multiple;
		if($action=='add')
		{
			echo 'Add '.$slug_name;
		}
		elseif($action=='update')
		{
			echo 'Update '.$slug_name;
		}
		elseif($action=='view')
		{
			echo 'View '.$slug_multiple;
		}

	}

	function view_table_headings(){
		global $fields;
  		foreach ($fields as  $field) {
  			echo "<th>".$field['label']."</th>";
  		}
	}

	function view_fields($row){
		global $fields;
  		foreach ($fields as $key => $field) {
			echo "<td>";
			//if field is text
			$field_name=$field['field'];
  			if ($field['type']=='text' || $field['type']=='email' || $field['type']=='select') {
  				echo $row[$field_name];
  			} else if ($field['type']=='file') {
  				if(!empty($row[$field_name])){
  				?>
					<img src="uploads/<?php echo $row[$field_name]; ?>" alt="" style='width:100px;'>
  				<?php
  				}
  			} elseif ($field['type']=='checkbox') {

       //   		$options=$field_name.'_options';
       //    		$check=$row[$field_name];
					// $op_ar=$$options;
					echo $row[$field_name];
  			}


  			echo "</td>";
  		}

	}

	function update_delete_btns($row){
		global $permissions,$slug;
		if ($permissions['delete']) {
		# code...
	
		?>
						  <a href="process.php?action=delete&delete=<?php echo $row['id']; ?>" class="btn btn-warning" onclick="return confirm('Are you sure you want to delete this?');">Delete</a>
		<?php 
			}
			if ($permissions['update']) {

		?>
						  <a href="<?php echo $slug;?>.php?action=update&update=<?php echo $row['id']; ?>" class="btn btn-info">Edit</a>
		<?php 
		}

	}

	//theme refactor

	function content_header(){
		?>
	    <!-- Content Header (Page header) -->
	    <section class="content-header">
		<?php add_button(); ?>      
	      <ol class="breadcrumb">
	        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
	      </ol>
	    </section>
		<br />

		<?php
	}

	function box_header(){
		?>
			<div class="box-header with-border">
			  <h3 class="box-title"><?php view_slug(); ?></h3>
			  <div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
			  <div class='row col-lg-12' style="margin-top:15px;"><?php msg(); ?></div>
			</div>

		<?php
	}

	function add_update(){
			global $action,$slug_name,$slug_multiple,$slug,$table,$fields,$options,$permissions;
			if($action=='add' || $action=='update')
			{
?>
		   <div class="box box-primary">
           
            <!-- /.box-header -->
            <!-- form start -->
            <form name="submit" action="process.php" method="post" enctype="multipart/form-data">
			<?php
				if($action=='update')
				{		
				$id = $_GET['update'];
				$row = a("$table where id = '$id'",false);
				echo '<input type="hidden" name="'.$slug.'_id" value="'.$id.'"/>';
				}
			?>

                  <?php 
                  		foreach ($fields as  $field) {
                  			$field_type=$field['type'];
                  			$field_name=$field['field'];
                  			$field_label=$field['label'];
                  			if ($field_type=='text' || $field_type=='email' || $field_type=='file') {
                  			?>

                <div class="form-group">
                  <label for="cat_title"><?php echo $field_label; ?></label>
                  <input type="<?php echo $field_type; ?>" value="<?php if(isset($_GET['update'])){echo $row[$field_name];}  ?>" name="<?php echo $field_name; ?>" class="form-control" placeholder="Enter <?php echo $field_label; ?>" <?php if($field_type!='file'){echo "required";} ?> >
                </div>

                  			<?php
                  			} else if($field_type=='select') {
?>
                <div class="form-group">
                  <label for="cat_title"><?php echo $field_label; ?></label>
                  <select name="<?php echo $field_name; ?>" id="" class="form-control">
						<?php 
						$select_options=$options[$field_name];
						foreach ($select_options as $key=> $option) {
							echo "<option";
							echo " value='".$key."' ";
							if(isset($_GET['update'])){
								if ($row[$field_name]==$key) {
									echo "selected";
								}
							}
							echo " >";
							echo $option;
							echo "</option>";


						}
						//if field type=text area

						 ?>
                  </select>
                  </div>

<?php
                 } elseif ($field_type=='textarea') {
                 	# code...
                 	?>
                <div class="form-group">
                  <label for="cat_title"><?php echo $field_label; ?></label>

     <textarea name="<?php echo $field_name; ?>" id="" cols="30" rows="10" class="form-control"><?php if(isset($_GET['update'])){echo $row[$field_name];}  ?></textarea>
   </div>          
                 	<?php
                 } elseif ($field_type=='checkbox') {
                 		$checkbox_options=$options[$field_name];
                 		?>
 <div class="form-group">
                  <label for="cat_title"><?php echo $field_label; ?></label>
					<br>
                  <?php
                  	if (isset($_GET['update'])) {

                  		$check=$row[$field_name];
                  		$checks=explode(',',$check);
                  	}

					foreach ($checkbox_options as $key => $option) {
						echo '<label class="checkbox-inline">';
						echo '<input type="checkbox" id="inlineCheckbox1" name="'.$field_name.'[]" value="'.$key.'" ';
						if (isset($_GET['update'])) {
							if (in_array($key,$checks)) {
								echo 'checked';
							}
						}
						echo '>'.$option;
						echo '</label>';
					}

                  ?>

   </div>      
                 		<?php
                 }

                  		}
                   ?>
                
				
              <!-- /.box-body -->

              <div class="box-footer">
				<?php if(isset($_GET['update'])){?>
                <button type="submit" name="update_<?php echo $slug; ?>" class="btn btn-primary">Update</button>
				<?php }else{?>
                <button type="submit" name="add_<?php echo $slug; ?>" class="btn btn-primary">Submit</button>
				<?php }?>
              </div>
            </form>
</div>
<?php
					}

	}

	function theme_aside(){
		?>
   <aside class="control-sidebar control-sidebar-dark">
    <div class="tab-content">
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
      <div class="tab-pane" id="control-sidebar-stats-tab"></div>
    </div>
  </aside>

		<?php
	}
?>