<?php
include("header.php");
include("aside.php");

/*
	=========================================================
	=========================================================
*/

$slug_name='User';
$slug_multiple='Users';
$slug='blank';
$table='users';

/*
	=========================================================
	=========================================================
*/

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>
<br />
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
		<div class="box">
			<div class="box-header with-border">
		<?php echo $slug_name.' Details'; ?>
			  <div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
				<div class='row col-lg-12' style="margin-top:15px;">
					<?php
						msg();
					?>
				</div>

			</div>
			<div class="box-body">           

          <table class="table table-bordered table-striped">
               
                <tbody>
               
				<?php
				$id=$_GET['id'];
				  $row = a("$table where id='$id'",false);
					
				?>
                <tr>
                  	<th></th>
                  	<td></td>
                </tr>
				 
                </tbody>
             
              </table>
           
    
						
						
			</div>
        <!-- /.box-body -->
		</div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


   <aside class="control-sidebar control-sidebar-dark">
    <div class="tab-content">
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
      <div class="tab-pane" id="control-sidebar-stats-tab"></div>
    </div>
  </aside>

<!-- ./wrapper -->

<?php include("footer.php");?>