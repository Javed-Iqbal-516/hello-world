<?php
include("header.php");
include("aside.php");

/*
	=========================================================
	=========================================================
*/
$slug_name='Password';
$slug_multiple='Password';
$slug='password';
$table='users';
$fields=array('first_name','email');
$_SESSION['record']=array(
							'table'=>$table,
							'slug_name'=>$slug_name,
							'slug'=>$slug,
							'fields'=>$fields,
							'photo'=>'',
						);

update_password('admin');
/*
	=========================================================
	=========================================================
*/

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
		Change Password
		<ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>
<br />
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
		<div class="box">
			<div class="box-header with-border">
			<h1>Change Password</h1>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
				<div class='row col-lg-12' style="margin-top:15px;">
					<?php
						msg();
					?>
				</div>

			</div>
			<div class="box-body">           

	
		   <div class="box box-primary">
           
					<form action="" method="post" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <div class="form-group">
                        <label class="form-label">Old Password</label>
                        <div class="controls">
                          <input type="password" class="form-control" name="old" required placeholder="Enter Old Password">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="form-label">New Password</label>
                        <div class="controls">
                          <input type="password" class="form-control" name="password" placeholder="Enter New Password" required  />
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <div class="controls">
                          <input type="password" class="form-control" name="confirm_pass" placeholder="Confirm New Password" required  />
                        </div>
                      </div>
					  
				<div class="form-group">
                <button type="submit" name="update_password" class="btn btn-primary">Update</button>
							</form>
					  </div>
                     </div>
                  </div>
					</form>


            <!-- form start -->
</div>
			</div>
        <!-- /.box-body -->
		</div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


   <aside class="control-sidebar control-sidebar-dark">
    <div class="tab-content">
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
      <div class="tab-pane" id="control-sidebar-stats-tab"></div>
    </div>
  </aside>

<!-- ./wrapper -->

<?php include("footer.php");?>