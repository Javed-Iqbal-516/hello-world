  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="uploads/<?php if($_SESSION['admin']['image']=='') {?>blank.gif<?php }else{echo $_SESSION['admin']['image'];} ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $suser['first_name']; ?></p>
        </div>
      </div>

      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="<?php a_c('index'); ?> treeview">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>

        <li class="treeview <?php a_c('user'); ?>">
          <a href="blank.php?action=view">
            <i class="fa fa-users"></i>
            <span>Blank</span>
          </a>

        </li>


       
        <li class="treeview <?php a_c('profile'); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Manage Profile</span>
      
         </a>
          <ul class="treeview-menu">
            <li><a href="profile.php"><i class="fa fa-circle-o"></i>Profile</a></li>
            <li><a href="password.php"><i class="fa fa-circle-o"></i>Change Password</a></li>
       
          </ul>

       </li>

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

