$('document').ready(function(){

/*
	==============================================================
*/

	$('.match-btn').click( function() {
		
		$('#typetype').val($(this).data('type'));
		$('#help_id').val($(this).data('help_id'));
	});

	$('.provide_help').submit( function(event){
			// alert('form is submit');
		var data = $(".provide_help").serialize();
		$.ajax({  
		   type: "POST",  
		   url: "ajax_provide_help.php",
		   data:data,
		   success: function(data) {
				$('.ajax_msg').html(data);
			}
		});	
		event.preventDefault();
	});//end submit

	$('#send_msg_from').submit(function(event) {
		var data = $(this).serialize();
		$('#msgtext').val('');
		$.ajax({  
		   type: "POST", 
		   url: "ajax/send_msg.php",
		   data:data,
		   success: function() {
				$('.messages').load("ajax/messages.php");
		   }
		});	
		event.preventDefault();
	});//end submit

	
	$('.like').click(function(){
		var pid=$(this).data('id');
		alert('pid');
	});
	
	$('.dislike').click(function(){
		var pid=$(this).data('id');
		alert('pid');
	});
	
/*
	==============================================================
*/
	});