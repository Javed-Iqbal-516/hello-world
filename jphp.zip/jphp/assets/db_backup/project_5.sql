-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2017 at 12:09 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_5`
--

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `id_field` varchar(300) NOT NULL,
  `field_value` int(11) NOT NULL,
  `type` varchar(300) NOT NULL,
  `active` int(11) DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `tbl` varchar(300) NOT NULL,
  `slug` varchar(300) NOT NULL,
  `slug_multiple` varchar(300) NOT NULL,
  `fields` text NOT NULL,
  `fields_name` text NOT NULL,
  `fields_label` text NOT NULL,
  `options` text NOT NULL,
  `validations` text NOT NULL,
  `permissions` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `tbl`, `slug`, `slug_multiple`, `fields`, `fields_name`, `fields_label`, `options`, `validations`, `permissions`) VALUES
(1, '', '', '', '', '[{"field":"first_name","label":"First Name","type":"text","validation":["one","two","three"]},{"field":"email","label":"Email","type":"email"},{"field":"image","label":"User Image","type":"file","file_types":["jpg","jpeg","png"],"size":"200000000","image":true},{"field":"sub_type","label":"Select Type","type":"select"},{"field":"checklist","label":"Checklist","type":"checkbox"}]', '', '', '', '', ''),
(2, '', '', '', '', '[{"field":"first_name","label":"First Name","type":"text","validation":{"new":["sub one","sub two"],"0":"one","1":"two","2":"three"}},{"field":"email","label":"Email","type":"email"},{"field":"image","label":"User Image","type":"file","file_types":["jpg","jpeg","png"],"size":"200000000","image":true},{"field":"sub_type","label":"Select Type","type":"select"},{"field":"checklist","label":"Checklist","type":"checkbox"}]', '', '', '', '', ''),
(3, '', '', '', '', '[{"field":"first_name","label":"First Name","type":"text","validation":{"new":["sub one","sub two"],"0":"one","1":"two","2":"three"}},{"field":"email","label":"Email","type":"email"},{"field":"image","label":"User Image","type":"file","file_types":["jpg","jpeg","png"],"size":"200000000","image":true},{"field":"sub_type","label":"Select Type","type":"select"},{"field":"checklist","label":"Checklist","type":"checkbox"}]', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_option` varchar(300) NOT NULL,
  `value` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_option`, `value`, `date`) VALUES
(2, 'site_name', 'Project 5.0', '2017-10-31 04:17:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(500) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(500) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL,
  `image` varchar(500) NOT NULL,
  `phone_no` varchar(300) NOT NULL,
  `active` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sub_type` varchar(300) NOT NULL,
  `checklist` varchar(300) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `email`, `password`, `type`, `image`, `phone_no`, `active`, `date`, `sub_type`, `checklist`) VALUES
(108, 'admin', 'admin@gmail.com', '315a1ed47e312413fb5df2e8b5e15200dde8ec582966bb129d65bb13e1b8cef6', 'admin', '1492771457EC120-B.jpg', '1235', 0, '2017-07-01 15:14:27', 'user', 'f_tax'),
(109, 'lorem_updated', 'admi33n@gmail.com', '', 'user', '', '', 0, '2017-07-11 20:22:39', 'user', 'legally');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
