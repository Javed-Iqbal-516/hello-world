$(function (){
		
	// alert('jquery is running');

/*==========================================================================*/	

	/* Code */



/*==========================================================================*/	

	/* Window scroll */
	$(window).scroll(function() {    
		var scroll = $(window).scrollTop();
		if ($(this).scrollTop() > 100) {
	        $('.btn-top').fadeIn();
	    } else {
	        $('.btn-top').fadeOut();
	    }
	});

	$(".btn-top").click(function() {
	  $("html, body").animate({ scrollTop: 0 }, "slow");
	  return false;
	});


	$(document).delegate('','change',function(){
		// $('#total_price').html($(this).parents('td').siblings('.net-total').html());
	});

/*  FUNCTIONS  */

	function log(data){
		console.log(data);
	}

/* ==============================================================================    */	
});
