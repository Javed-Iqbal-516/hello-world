<?php 

	if (set('page')) {
		$page=g('page');
		include("modules/controllers/".$page.".php");
	}
?>